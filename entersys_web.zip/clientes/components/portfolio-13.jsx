"use client";

import { Badge, Button, Card } from "@relume_io/relume-ui";
import React from "react";
import { RxChevronRight } from "react-icons/rx";

export function Portfolio13() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="mx-auto mb-12 max-w-lg text-center md:mb-18 lg:mb-20">
          <p className="mb-3 font-semibold md:mb-4">Portafolio</p>
          <h2 className="mb-5 text-5xl font-bold md:mb-6 md:text-7xl lg:text-8xl">
            Nuestros casos de éxito
          </h2>
          <p className="md:text-md">
            Proyectos que demuestran nuestra capacidad de transformación
          </p>
        </div>
        <div className="grid grid-cols-1 gap-x-8 gap-y-12 md:grid-cols-2 md:gap-y-16 lg:grid-cols-3">
          <Card>
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">Manufactura automotriz</a>
              </h3>
              <p>
                Optimización de procesos de producción con sistemas inteligentes
              </p>
              <div className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <Badge>
                  <a href="#">Eficiencia</a>
                </Badge>
                <Badge>
                  <a href="#">Digitalización</a>
                </Badge>
                <Badge>
                  <a href="#">Automatización</a>
                </Badge>
              </div>
              <Button
                title="Ver proyecto"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                className="mt-5 md:mt-6"
              >
                <a href="#">Ver proyecto</a>
              </Button>
            </div>
          </Card>
          <Card>
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">Retail tecnológico</a>
              </h3>
              <p>
                Implementación de sistema de gestión para cumplimiento normativo
              </p>
              <div className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <Badge>
                  <a href="#">Cumplimiento</a>
                </Badge>
                <Badge>
                  <a href="#">Gestión</a>
                </Badge>
                <Badge>
                  <a href="#">Transformación</a>
                </Badge>
              </div>
              <Button
                title="Ver proyecto"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                className="mt-5 md:mt-6"
              >
                <a href="#">Ver proyecto</a>
              </Button>
            </div>
          </Card>
          <Card>
            <div>
              <a href="#">
                <img
                  src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
                  className="w-full object-cover"
                  alt="Relume placeholder image"
                />
              </a>
            </div>
            <div className="px-5 py-6 sm:px-6">
              <h3 className="mb-2 text-xl font-bold md:text-2xl">
                <a href="#">Servicios financieros</a>
              </h3>
              <p>
                Integración de dashboards para toma de decisiones estratégicas
              </p>
              <div className="mt-3 flex flex-wrap gap-2 md:mt-4">
                <Badge>
                  <a href="#">Inteligencia</a>
                </Badge>
                <Badge>
                  <a href="#">Datos</a>
                </Badge>
                <Badge>
                  <a href="#">Estrategia</a>
                </Badge>
              </div>
              <Button
                title="Ver proyecto"
                variant="link"
                size="link"
                iconRight={<RxChevronRight />}
                className="mt-5 md:mt-6"
              >
                <a href="#">Ver proyecto</a>
              </Button>
            </div>
          </Card>
        </div>
        <div className="mt-12 flex justify-center md:mt-18 lg:mt-20">
          <Button title="Ver todos" variant="secondary" size="primary">
            Ver todos
          </Button>
        </div>
      </div>
    </section>
  );
}
